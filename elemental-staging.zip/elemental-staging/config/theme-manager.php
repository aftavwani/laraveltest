<?php

return array(
    
    'themes_dir' => '/public/themes',

    'active' => 'default',
);
