<?php
return [
    'layout_paths' => [
        'layouts' => resource_path('views/layouts/')
    ],
];