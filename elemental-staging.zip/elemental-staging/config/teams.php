<?php


return [

    'user_model' => Humweb\Auth\Users\User::class,

    /**
     * Invitation expiration in days
     */
    'invitation_expiration' => 7,

];